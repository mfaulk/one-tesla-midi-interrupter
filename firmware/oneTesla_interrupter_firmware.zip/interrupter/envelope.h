#ifndef __ENVELOPE_H

#include "system.h"
#include "note.h"

float envelope_scaler(volatile note* n);

#define __ENVELOPE_H
#endif
